﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Giniyatullina_Kanaeva_pr21_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Department> department = new List<Department>()
            {
                new Department() { Name = "Отдел закупок", Reg = "Германия" },
                new Department() { Name = "Отдел продаж", Reg = "Испания" },
                new Department() { Name = "Отдел маркетинга", Reg = "Испания" }
            };
        List<Employ> employs = new List<Employ>()
            {
                new Employ { Name = "Иванов", Department = "Отдел закупок" },
                new Employ { Name = "Петров", Department = "Отдел закупок" },
                new Employ { Name = "Сидоров", Department = "Отдел продаж" },
                new Employ { Name = "Лямин", Department = "Отдел продаж" },
                new Employ { Name = "Сидоренко", Department = "Отдел маркетинга" },
                new Employ { Name = "Кривоносов", Department = "Отдел продаж" },
            };

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < department.Count; i++)
            {
                listBox1.Items.Add(department[i].Name + " - " + department[i].Reg);
            }
            for (int i = 0; i < employs.Count; i++)
            {
                listBox2.Items.Add(employs[i].Name + " - " + employs[i].Department);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            var groups1 = from emp in employs
                          from dep in department
                          where emp.Department == dep.Name
                          select new
                          {
                              EmployName = emp.Name,
                              DepartmentName = emp.Department,
                              Region = dep.Reg
                          };
            foreach (var group in groups1)
            {
                listBox3.Items.Add(group.EmployName + " - " + group.DepartmentName + " - " + group.Region);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            var groups1 = from emp in employs
                          from dep in department
                          where emp.Department == dep.Name
                          select new
                          {
                              EmployName = emp.Name,
                              DepartmentName = emp.Department,
                              Region = dep.Reg
                          };
            var groups2 = groups1.GroupBy(emp => emp.DepartmentName);
            foreach (var group in groups2)
            {
                listBox3.Items.Add($"<<{group.Key}>>");
                foreach (var item in group)
                {
                    listBox3.Items.Add($"{item.EmployName} - {item.Region}");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            var groups1 = from emp in employs
                          from dep in department
                          where emp.Department == dep.Name
                          select new
                          {
                              EmployName = emp.Name,
                              DepartmentName = emp.Department,
                              Region = dep.Reg
                          };
            var groups3 = groups1.Where(r => r.Region.StartsWith("И"));
            foreach (var item in groups3)
            {
                listBox3.Items.Add($"{item.EmployName} — {item.DepartmentName}");
            }
        }
    }
}
