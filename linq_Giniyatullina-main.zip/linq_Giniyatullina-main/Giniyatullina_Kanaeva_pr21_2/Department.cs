﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Giniyatullina_Kanaeva_pr21_2
{
    internal class Department
    {
        private string name;
        private string reg;
        public string Name { get { return name; } set { name = value; } }
        public string Reg { get { return reg; } set { reg = value; } }

    }
}
