﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Giniyatullina_Kanaeva_pr21_2
{
    internal class Employ
    {
        private string name;
        private string department;
        public string Name { get { return name; } set { name = value; } }
        public string Department { get { return department; } set { department = value; } }

    }
}
