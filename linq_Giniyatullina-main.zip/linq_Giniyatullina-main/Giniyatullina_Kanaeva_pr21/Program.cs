﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Giniyatullina_Kanaeva_pr21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string[] mas = File.ReadAllLines("file.txt");
                People[] users1 = new People[mas.Length];
                for (int i = 0; i < mas.Length; i++)
                {
                    string[] line = mas[i].Split(' ');
                    users1[i] = new People(line[0], line[1], line[2], int.Parse(line[3]), int.Parse(line[4]));
                }
                var users2 = users1.Where(u => u.Age < 40).ToArray();
                Console.WriteLine("Пользователи младше 40:");
                foreach (People user in users2)
                {
                    Console.WriteLine(user.Info());
                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Файл не найден");
            }
        }
    }
}
