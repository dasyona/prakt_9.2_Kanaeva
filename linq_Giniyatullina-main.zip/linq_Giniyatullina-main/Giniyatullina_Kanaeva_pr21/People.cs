﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Giniyatullina_Kanaeva_pr21
{
    internal class People
    {
        private string surname;
        private string name;
        private string otchestvo;
        private int age;
        private int ves;
        public string Sername { get { return surname; } set { surname = value; } }
        public string Name { get { return name; } set { name = value; } }
        public string Otchestvo { get { return otchestvo; } set { otchestvo = value; } }
        public int Age { get { return age; } set { age = value; } }
        public int Ves { get { return ves; } set { ves = value; } }
        public People(string surname, string name, string otchestvo, int age, int ves)
        {
            this.surname = surname;
            this.name = name;
            this.otchestvo = otchestvo;
            this.age = age;
            this.ves = ves;
        }
        public string Info()
        {
             return surname + " " + name + " " + otchestvo + " " + age + " " + ves;
        }
    }
}

